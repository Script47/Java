/**
 * Created by Script47 on 16/04/2014.
 * Holds the main game.
 */
package script47.guess.the.number;